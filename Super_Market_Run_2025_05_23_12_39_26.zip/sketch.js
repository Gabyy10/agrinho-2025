let carrinho;
let obstaculos = [];
let alimentos = [];
let vias = 7;
let tamanhoCelda = 60;
let jogoIniciado = false;
let pontuacao = 0;
let vidas = 3;
let velocidadeJogo = 3;
let invencivel = false;
let tempoPiscando = 0;
let telaAtual = "inicio"; // Variável faltante adicionada
let ultimoObstaculo = 0;
let ultimoAlimento = 0;

function setup() {
  createCanvas(400, 420);
  carrinho = {
    x: width / 2,
    y: height - tamanhoCelda / 2,
    tamanho: tamanhoCelda * 0.7
  };
}

function draw() {
  if (!jogoIniciado) {
    if (telaAtual === "inicio") {
      telaInicio();
    } else if (telaAtual === "gameover") {
      desenharTelaGameOver();
    }
  } else {
    desenharCenario();
    atualizarObstaculos();
    atualizarAlimentos();
    desenharCarrinho();
    desenharPontuacao();
    desenharVidas();
    
    // Gera obstáculos com intervalo de tempo
    if (millis() - ultimoObstaculo > 1000) {
      gerarObstaculo();
      ultimoObstaculo = millis();
    }
    
    // Gera alimentos com intervalo de tempo
    if (millis() - ultimoAlimento > 1500) {
      gerarAlimento();
      ultimoAlimento = millis();
    }
    
    // Controle de invencibilidade após colisão
    if (invencivel && millis() - tempoPiscando > 2000) {
      invencivel = false;
    }
  }
}

function mousePressed() {
  if (!jogoIniciado) {
    if (telaAtual === "inicio" && mouseX > width/2 - 80 && mouseX < width/2 + 80 && 
        mouseY > height/2 + 50 && mouseY < height/2 + 100) {
      jogoIniciado = true;
      vidas = 3;
      pontuacao = 0;
      obstaculos = [];
      alimentos = [];
    } else if (telaAtual === "gameover" && mouseX > width/2 - 80 && mouseX < width/2 + 80 && 
               mouseY > height/2 + 100 && mouseY < height/2 + 150) {
      reiniciarJogo();
    }
  }
}

function keyPressed() {
  if (jogoIniciado) {
    if (key === 'ArrowUp' && carrinho.y > tamanhoCelda / 2) {
      carrinho.y -= tamanhoCelda;
    } else if (key === 'ArrowDown' && carrinho.y < height - tamanhoCelda / 2) {
      carrinho.y += tamanhoCelda;
    } else if (key === 'ArrowLeft' && carrinho.x > tamanhoCelda / 2) {
      carrinho.x -= tamanhoCelda;
    } else if (key === 'ArrowRight' && carrinho.x < width - tamanhoCelda / 2) {
      carrinho.x += tamanhoCelda;
    }
  }
}

function telaInicio() {
  background(220);
  fill(50);
  textSize(28);
  textAlign(CENTER);
  text("🛒 Super Market Run", width/2, height/2 - 60);
  
  textSize(16);
  text("Colete frutas (🍎, 🍒) e evite carros (🚗) e buracos (🕳️)", width/2, height/2);
  text("Use as setas ↑ ↓ ← → para se mover | Vidas: ❤️❤️❤️", width/2, height/2 + 30);
  
  fill(34, 139, 34);
  rect(width/2 - 80, height/2 + 50, 160, 50, 10);
  fill(255);
  textSize(20);
  text("Jogar", width/2, height/2 + 80);
}

function desenharCenario() {
  // Grama (fundo)
  for (let i = 0; i < vias; i++) {
    if (i % 2 == 0) {
      fill(144, 238, 144);
    } else {
      fill(34, 139, 34);
    }
    rect(0, i * tamanhoCelda, width, tamanhoCelda);
  }
  
  // Faixas da rua (cinza)
  for (let i = 2; i < vias; i += 2) {
    fill(100);
    rect(0, i * tamanhoCelda, width, tamanhoCelda);
    
    // Linhas divisórias da rua
    fill(255);
    for (let j = 0; j < width; j += 40) {
      rect(j, i * tamanhoCelda + tamanhoCelda / 2 - 5, 20, 5);
    }
  }
}

function gerarObstaculo() {
  // Gera obstáculos apenas nas faixas da rua (índices 2, 4, 6)
  let faixa = 2 + floor(random(3)) * 2;
  let tiposObstaculos = ['🚗', '🏍️', '🕳️'];
  let tipoObstaculo = random(tiposObstaculos);
  
  // Define a direção baseada no tipo de obstáculo
  let direitaParaEsquerda = random() > 0.5;
  let xInicial = direitaParaEsquerda ? width + 50 : -50;
  let velocidade = random(2, 5) * (direitaParaEsquerda ? -1 : 1);
  
  obstaculos.push({
    x: xInicial,
    y: faixa * tamanhoCelda + tamanhoCelda / 2,
    tipo: tipoObstaculo,
    velocidade: velocidade
  });
}

function gerarAlimento() {
  // Gera alimentos apenas nas faixas da rua (índices 2, 4, 6)
  let faixa = 2 + floor(random(3)) * 2;
  let tiposAlimentos = ['🍎', '🍒', '🥝'];
  let tipoAlimento = random(tiposAlimentos);
  
  alimentos.push({
    x: random(width),
    y: faixa * tamanhoCelda + tamanhoCelda / 2,
    tipo: tipoAlimento
  });
}

function atualizarObstaculos() {
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    let obs = obstaculos[i];
    obs.x += obs.velocidade * velocidadeJogo;
    
    textSize(30);
    text(obs.tipo, obs.x, obs.y);
    
    // Remove obstáculos que saíram da tela
    if ((obs.velocidade < 0 && obs.x < -100) || (obs.velocidade > 0 && obs.x > width + 100)) {
      obstaculos.splice(i, 1);
    }
    
    // Verifica colisão
    if (!invencivel && dist(carrinho.x, carrinho.y, obs.x, obs.y) < tamanhoCelda / 2) {
      perderVida();
    }
  }
}

function atualizarAlimentos() {
  for (let i = alimentos.length - 1; i >= 0; i--) {
    let alimento = alimentos[i];
    textSize(30);
    text(alimento.tipo, alimento.x, alimento.y);
    
    // Verifica se o carrinho pegou o alimento
    if (dist(carrinho.x, carrinho.y, alimento.x, alimento.y) < tamanhoCelda / 2) {
      alimentos.splice(i, 1);
      pontuacao += 10; // Aumenta a pontuação mais significativamente
    }
  }
}

function desenharCarrinho() {
  if (!invencivel || (invencivel && frameCount % 10 < 5)) {
    textSize(30);
    text('🛒', carrinho.x, carrinho.y);
  }
}

function desenharPontuacao() {
  fill(0);
  textSize(20);
  text(`Pontuação: ${pontuacao}`, 20, 30);
}

function desenharVidas() {
  fill(255, 0, 0);
  textSize(20);
  let vidasText = "";
  for (let i = 0; i < vidas; i++) {
    vidasText += "❤️";
  }
  text(`Vidas: ${vidasText}`, width - 150, 30);
}

function perderVida() {
  vidas--;
  invencivel = true;
  tempoPiscando = millis();
  
  if (vidas <= 0) {
    fimDoJogo();
  }
}

function fimDoJogo() {
  jogoIniciado = false;
  telaAtual = "gameover";
}

function desenharTelaGameOver() {
  background(220);
  fill(255, 0, 0);
  textSize(32);
  textAlign(CENTER);
  text("Game Over!", width/2, height/2 - 40);
  
  fill(0);
  textSize(24);
  text(`Pontuação final: ${pontuacao}`, width/2, height/2);
  
  fill(34, 139, 34);
  rect(width/2 - 80, height/2 + 100, 160, 50, 10);
  fill(255);
  textSize(20);
  text("Jogar Novamente", width/2, height/2 + 130);
}

function reiniciarJogo() {
  jogoIniciado = true;
  telaAtual = "inicio";
  vidas = 3;
  pontuacao = 0;
  obstaculos = [];
  alimentos = [];
  carrinho.x = width / 2;
  carrinho.y = height - tamanhoCelda / 2;
  invencivel = false;
}